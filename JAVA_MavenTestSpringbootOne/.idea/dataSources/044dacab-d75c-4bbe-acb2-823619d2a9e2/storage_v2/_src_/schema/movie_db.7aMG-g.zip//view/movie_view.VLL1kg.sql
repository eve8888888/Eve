create view movie_view as
  select `movie_db`.`movie_table`.`movie_id`         AS `movie_id`,
         `movie_db`.`movie_table`.`movie_name`       AS `movie_name`,
         `movie_db`.`movie_table`.`movie_price`      AS `movie_price`,
         `movie_db`.`movie_table`.`movie_desc`       AS `movie_desc`,
         `movie_db`.`movie_table`.`movie_pic`        AS `movie_pic`,
         `movie_db`.`movie_table`.`movie_type`       AS `movie_type`,
         `movie_db`.`movie_table`.`movie_date`       AS `movie_date`,
         `movie_db`.`movie_table`.`movie_rate`       AS `movie_rate`,
         `movie_db`.`movie_table`.`moive_director`   AS `moive_director`,
         `movie_db`.`movie_table`.`movie_cinema`     AS `movie_cinema`,
         `movie_db`.`type_table`.`type_id`           AS `type_id`,
         `movie_db`.`type_table`.`type_name`         AS `type_name`,
         `movie_db`.`director_table`.`director_id`   AS `director_id`,
         `movie_db`.`director_table`.`director_name` AS `director_name`,
         `movie_db`.`director_table`.`director_desc` AS `director_desc`,
         `movie_db`.`cinema_table`.`cinema_id`       AS `cinema_id`,
         `movie_db`.`cinema_table`.`cinema_name`     AS `cinema_name`,
         `movie_db`.`cinema_table`.`cinema_address`  AS `cinema_address`,
         `movie_db`.`cinema_table`.`cinema_phone`    AS `cinema_phone`
  from `movie_db`.`movie_table`
         join `movie_db`.`type_table`
         join `movie_db`.`director_table`
         join `movie_db`.`cinema_table`
  where ((`movie_db`.`movie_table`.`movie_type` = `movie_db`.`type_table`.`type_id`) and
         (`movie_db`.`movie_table`.`movie_cinema` = `movie_db`.`cinema_table`.`cinema_id`) and
         (`movie_db`.`movie_table`.`moive_director` = `movie_db`.`director_table`.`director_id`));

